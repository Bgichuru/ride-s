<?php
class User_model extends CI_Model {
	public function __construct()
	{
		$this->load->database();
	}
	
	
	public function get_users() 
	{
		return $this->db->query("select u.*, p.Name profile_name from users u inner join profiles p on u.profile_ID = p.id  ")->result();
	}
	
	public function get_user($id)
	{
		return $this->db->query("SELECT * FROM users WHERE id=".$id)->row();
	}
	
	public function save_user($details) 
	{
		$this->db->insert('users', $details);
		return $this->db->insert_id();
	}
	
	public function update_user($id, $data)
	{
		$this->db->update('users', $data,array('id' => $id));
		return $this->db->affected_rows();
	}
	
	public function delete_user($id)
	{
		$this->db->query("DELETE FROM users WHERE id='".$id."'");
	}
	
	//-----------------------------------------------------------------
	public function get_credentials($username,$password)
	{   
	    $usr = $this->db->escape($username);
		$pass = $this->db->escape($password);
		
		return $this->db->query("SELECT * FROM users WHERE userName = ".$usr." and password=".$pass)->row();
	}
	
	public function login_user($id){
		$this->db->query("UPDATE users SET lastLoginDate = now() WHERE id =".$id);
	}
}
?>