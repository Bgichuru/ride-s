<?php
class Users extends CI_controller {
	
	public function __construct()
	{
		parent::__construct();
		try{
		    //$this->load->model('audittrail_model');
			//$this->load->model('rights_model');
			$this->load->model('user_model');
	
		}catch (Exception $ex){
			http_response_code(401);
			exit;
		}
	}

	public function index()
	{
		
	}
	
	public function load()
	{
		$this->output
			 ->set_content_type('application/json')
			 ->set_output('{"data":'.json_encode( $this->user_model->get_users(AGENT_ID)).'}');
	}

	public function add_user()
	{
		$now = new DateTime();
        //$profile = $this->input->post('profile');
	
			/*$data = array(
					'userName'  => $this->input->post('username'),
					'password'  => "pass",
					'fullnames' => $this->input->post('fullnames'),
					'phone' => $this->input->post('phone'),
					'email' => $this->input->post('email'),
					'lastLoginDate' => $now->format('Y-m-d H:i:s'),
					'profile_ID' => $this->input->post('profile'),
					'agent_id'   => $this->input->post('agent_id'),
					'accountStatus' => $profile == 77 ? 1 : $this->input->post('accountStatus') //sysadmin must be active 
				);*/
				
				$input_data = json_decode($this->input->raw_input_stream, true);
				
		
		
		$insert = $this->user_model->save_user($input_data);
		$this->output
			 ->set_content_type('application/json')
			 ->set_output(json_encode(array("status" => TRUE)));
	}
	
	public function edit_user($id)
	{
		$this->output
			 ->set_content_type('application/json')
			 ->set_output(json_encode($this->user_model->get_user($id)));
	}
	
    public function update_user($id)
	{
		$usr = $this->user_model->get_user($id);
		
		if ($usr->profile_id == 77 && $this->input->post('accountStatus') == 0 ){
			$resp = array(
						"status" => FALSE,
						"msg" => "Super Admin users cannot be Deactivated!"
					);
					
			echo json_encode($resp);
			exit;
		}
		
		$data = array(
				'userName' => $this->input->post('username'),
				'FullNames' => $this->input->post('fullnames'),
				'email' => $this->input->post('email'),
				'phone' => $this->input->post('phone'),
				'agent_id'   => $this->input->post('agent_id'),
			    'profile_id' => $this->input->post('profile'),
			    'accountStatus' => $this->input->post('accountStatus'),
			);
		$this->user_model->update_user($id, $data);
		
		$this->output
			 ->set_content_type('application/json')
			 ->set_output(json_encode(array("status" => TRUE)));
	}
	
	public function delete_user($id)
	{
		if ($this->user_model->get_user($id)->profile_ID == 77){
			echo json_encode(array(
						"status" => FALSE,
						"msg" => "Super Admin users cannot be Deleted!"
				 ));
			exit;
		}
		$this->user_model->delete_user($id);
		$this->output
			 ->set_content_type('application/json')
			 ->set_output(json_encode(array("status" => TRUE)));
	}
	
	
}
?>